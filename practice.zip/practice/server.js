const express = require('express');
const { fetch } = require('undici');
const app = express();
const PORT = 3000;

const TELEGRAM_TOKEN = '7304058017:AAHrb71-KZ307Kofo2y1t7HgBNYBODPXGyQ';
const CHAT_ID = '1206591128'; // Куда отправлять заявки

app.use(express.json());
app.use(express.static('public')); // папка для index.html

app.post('/send', async (req, res) => {
  const { name, phone, message } = req.body;
  const text = `Новая заявка:\nИмя: ${name}\nТелефон: ${phone}\nПроблема: ${message}`;
  
  await fetch(`https://api.telegram.org/bot${TELEGRAM_TOKEN}/sendMessage`, {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({
      chat_id: CHAT_ID,
      text: text
    })
  });

  res.sendStatus(200);
});

app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));
